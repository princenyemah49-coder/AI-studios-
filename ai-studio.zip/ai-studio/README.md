# 🎬 AI Studio

An AI-powered video creation app — create avatar videos, translate, and generate content with AI.

## 🚀 Deploy to Vercel (Free - Recommended)

1. **Install Git** if you don't have it: https://git-scm.com
2. **Create GitHub account**: https://github.com
3. Upload this folder to a new GitHub repo
4. Go to **https://vercel.com** → Sign up with GitHub
5. Click **"Add New Project"** → Import your repo
6. Click **Deploy** — done! You get a free URL like `ai-studio.vercel.app`

## 🌐 Deploy to Netlify (Alternative)

1. Go to **https://netlify.com** → Sign up free
2. Drag and drop the `/build` folder (after running `npm run build`)
3. Get instant free URL

## 💻 Run Locally

```bash
# Install dependencies
npm install

# Start development server
npm start

# Open http://localhost:3000
```

## 📦 Build for Production

```bash
npm run build
```

This creates a `/build` folder ready to upload anywhere.

## ⚡ Quick Deploy via StackBlitz (Instant, no setup)

1. Go to https://stackblitz.com
2. Click "Import from GitHub"
3. Paste your repo URL
4. Share the live link instantly

## 🔧 Tech Stack

- React 18
- Anthropic Claude API (AI features)
- No backend needed — runs 100% in the browser

## 📝 Notes

- The app calls the Anthropic API directly from the browser
- For production, move API calls to a backend to protect your API key
- Current features: Text to Video, Avatar Maker, Translate, Shortcuts
